# Gambit Gaming App Starter

Original React/Vite starter for a gaming-style app dashboard. This project does not copy proprietary code or assets from wallz.gg.

## Run

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## What is included

- Responsive React app
- Game cards and search
- Sidebar navigation
- Hero section
- Mobile-friendly layout
