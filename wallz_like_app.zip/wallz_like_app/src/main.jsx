import React, {useMemo, useState} from 'react';
import { createRoot } from 'react-dom/client';
import { Search, Gamepad2, Trophy, Wallet, User, Menu, Star, Zap } from 'lucide-react';
import './styles.css';

const games = [
  {title:'Crash Arena', genre:'Arcade', players:'2.4k', tag:'Hot', gradient:'g1'},
  {title:'Tower Run', genre:'Strategy', players:'980', tag:'New', gradient:'g2'},
  {title:'Neon Dice', genre:'Luck', players:'4.1k', tag:'Live', gradient:'g3'},
  {title:'Rocket Flip', genre:'Fast', players:'1.7k', tag:'Top', gradient:'g4'},
  {title:'Mystery Box', genre:'Rewards', players:'3.2k', tag:'Drop', gradient:'g5'},
  {title:'Battle Grid', genre:'PvP', players:'720', tag:'Beta', gradient:'g6'}
];

function App(){
  const [query,setQuery]=useState('');
  const filtered=useMemo(()=>games.filter(g=>g.title.toLowerCase().includes(query.toLowerCase())||g.genre.toLowerCase().includes(query.toLowerCase())),[query]);
  return <div className="app">
    <aside className="sidebar">
      <div className="brand"><span className="logo"><Gamepad2 size={24}/></span><b>Gambit</b></div>
      <nav>
        <a className="active"><Zap size={18}/>Play</a><a><Trophy size={18}/>Leaderboard</a><a><Wallet size={18}/>Wallet</a><a><User size={18}/>Profile</a>
      </nav>
    </aside>
    <main>
      <header>
        <button className="icon"><Menu/></button>
        <div className="search"><Search size={18}/><input placeholder="Search games..." value={query} onChange={e=>setQuery(e.target.value)}/></div>
        <button className="login">Sign in</button>
      </header>
      <section className="hero">
        <div><p className="eyebrow">Featured game hub</p><h1>Play fast mini-games with a clean app experience.</h1><p className="muted">A legal original starter template inspired by modern gaming dashboards.</p><button>Start playing</button></div>
        <div className="hero-card"><Star/><h3>Daily Bonus</h3><p>Claim coins every day and unlock premium rooms.</p></div>
      </section>
      <section className="stats"><div><b>12.8k</b><span>Online</span></div><div><b>48</b><span>Games</span></div><div><b>99%</b><span>Uptime</span></div></section>
      <h2>Games</h2>
      <section className="grid">{filtered.map(g=><article className="card" key={g.title}><div className={'art '+g.gradient}><span>{g.tag}</span></div><div className="card-body"><h3>{g.title}</h3><p>{g.genre} • {g.players} players</p><button>Play</button></div></article>)}</section>
    </main>
  </div>
}

createRoot(document.getElementById('root')).render(<App/>);
